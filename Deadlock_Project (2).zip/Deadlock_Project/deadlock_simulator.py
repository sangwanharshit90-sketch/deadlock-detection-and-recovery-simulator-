# DEADLOCK DETECTION AND RECOVERY SIMULATOR
# Educational simulator for Operating Systems.
# This simulates resource allocation; it does not manage real OS processes.

def print_matrix(title, matrix):
    print("\n" + title)
    for i, row in enumerate(matrix):
        print(f"P{i}: {row}")


def get_input():
    print("\n===== DEADLOCK DETECTION AND RECOVERY SIMULATOR =====")
    try:
        n = int(input("Enter number of processes: "))
        m = int(input("Enter number of resource types: "))
        if n <= 0 or m <= 0:
            raise ValueError("Counts must be positive.")

        print("\nEnter Allocation Matrix (one row per process):")
        allocation = []
        for i in range(n):
            row = list(map(int, input(f"P{i}: ").split()))
            if len(row) != m or any(x < 0 for x in row):
                raise ValueError(f"P{i} must contain {m} non-negative integers.")
            allocation.append(row)

        print("\nEnter Request Matrix (one row per process):")
        request = []
        for i in range(n):
            row = list(map(int, input(f"P{i}: ").split()))
            if len(row) != m or any(x < 0 for x in row):
                raise ValueError(f"P{i} must contain {m} non-negative integers.")
            request.append(row)

        available = list(map(int, input("\nEnter Available Resources: ").split()))
        if len(available) != m or any(x < 0 for x in available):
            raise ValueError(f"Available must contain {m} non-negative integers.")

        return allocation, request, available

    except ValueError as exc:
        print(f"\nInvalid input: {exc}")
        return None, None, None


def detect_deadlock(allocation, request, available):
    """Return (completed_sequence, unfinished_processes, final_work)."""
    n = len(allocation)
    m = len(available)
    work = available.copy()
    finish = [False] * n
    sequence = []

    # Processes holding no resources can finish immediately.
    for i in range(n):
        if all(value == 0 for value in allocation[i]):
            finish[i] = True
            sequence.append(i)

    changed = True
    while changed:
        changed = False
        for i in range(n):
            if finish[i]:
                continue
            if all(request[i][j] <= work[j] for j in range(m)):
                for j in range(m):
                    work[j] += allocation[i][j]
                finish[i] = True
                sequence.append(i)
                changed = True

    unfinished = [i for i in range(n) if not finish[i]]
    return sequence, unfinished, work


def display_result(allocation, request, available, sequence, deadlocked, work):
    print("\n========== SYSTEM ANALYSIS ==========")
    print_matrix("ALLOCATION MATRIX", allocation)
    print_matrix("REQUEST MATRIX", request)
    print("\nAVAILABLE RESOURCES:", available)

    if deadlocked:
        print("\nSTATUS: DEADLOCK DETECTED")
        print("Processes unable to finish:", [f"P{i}" for i in deadlocked])
        print("Processes able to finish:", [f"P{i}" for i in sequence])
    else:
        print("\nSTATUS: NO DEADLOCK DETECTED")
        print("Completion sequence:", [f"P{i}" for i in sequence])

    print("Work vector after simulated completions:", work)


def recover(allocation, request, available, deadlocked):
    """Recover by terminating a selected unfinished process and releasing its allocation."""
    while deadlocked:
        print("\n========== RECOVERY OPTIONS ==========")
        print("Unfinished processes:", [f"P{i}" for i in deadlocked])
        print("1. Terminate one unfinished process")
        print("2. Exit without recovery")
        choice = input("Enter choice: ").strip()

        if choice == "2":
            print("Recovery cancelled.")
            return
        if choice != "1":
            print("Invalid choice. Select 1 or 2.")
            continue

        try:
            pid = int(input("Enter process number to terminate (e.g. 0 for P0): "))
            if pid not in deadlocked:
                print("Choose a process from the unfinished-process list.")
                continue

            print(f"\nTerminating simulated process P{pid}...")
            for j in range(len(available)):
                available[j] += allocation[pid][j]
                allocation[pid][j] = 0
                request[pid][j] = 0

            print(f"Resources allocated to P{pid} have been released.")
            sequence, deadlocked, work = detect_deadlock(
                allocation, request, available
            )
            display_result(
                allocation, request, available, sequence, deadlocked, work
            )

        except ValueError:
            print("Please enter a valid process number.")

    print("\nRECOVERY SUCCESSFUL: all remaining processes can complete.")


def main():
    allocation, request, available = get_input()
    if allocation is None:
        return

    sequence, deadlocked, work = detect_deadlock(
        allocation, request, available
    )
    display_result(allocation, request, available, sequence, deadlocked, work)

    if deadlocked:
        recover(allocation, request, available, deadlocked)

    print("\nThank you for using the Deadlock Simulator!")


if __name__ == "__main__":
    main()
