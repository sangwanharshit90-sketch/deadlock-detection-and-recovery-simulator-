# Deadlock Detection & Recovery Simulator

A beginner-friendly Operating Systems capstone project written in Python 3.
It simulates deadlock detection using Allocation, Request, and Available
resource data, and demonstrates recovery by terminating a selected unfinished
process and releasing its allocated resources.

> This is an educational simulator. It does not detect or terminate real
> Ubuntu operating-system processes.

## Requirements
- Ubuntu or another Linux distribution
- Python 3 (no third-party packages required)

Check Python:
```bash
python3 --version
```

## Run
```bash
python3 deadlock_simulator.py
```

## Sample input
Use the following data to demonstrate a deadlock:

```text
Enter number of processes: 3
Enter number of resource types: 2

Allocation Matrix:
P0: 1 0
P1: 0 1
P2: 0 0

Request Matrix:
P0: 0 1
P1: 1 0
P2: 0 0

Available Resources: 0 0
```

The simulator identifies P0 and P1 as unfinished/deadlocked while P2 can
complete. Select recovery option 1 and terminate process 0 or 1 to release
its allocated resource, then the simulator runs detection again.

## Project files
- `deadlock_simulator.py` — main program
- `test_cases.txt` — sample and validation test cases
- `screenshots/` — add your own Ubuntu terminal screenshots here

## Important concepts
- Deadlock detection
- Allocation and Request matrices
- Available resource vector
- Work and Finish vectors
- Recovery through process termination
- Resource release

## Limitations
- Uses a simplified single-instance/multiple-resource-count detection model.
- The input Request matrix represents current outstanding requests.
- Termination is simulated; no real processes are killed.
- This is deadlock detection, not the Banker's safety algorithm based on a
  Maximum matrix and Need = Maximum - Allocation.

## Suggested extensions
- Add a graphical interface.
- Draw a Resource Allocation Graph.
- Save results to a report or CSV file.
- Add automated test cases and recovery statistics.
